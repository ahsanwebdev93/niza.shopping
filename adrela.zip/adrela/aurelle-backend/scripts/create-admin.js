// Usage: npm run admin -- you@example.com YourStrongPassword
require('dotenv').config();
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');
(async () => {
  const [email, password] = process.argv.slice(2);
  if (!email || !password || password.length < 10) { console.error('Usage: npm run admin -- <email> <password (10+ chars)>'); process.exit(1); }
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false });
  const hash = await bcrypt.hash(password, 12);
  await pool.query('INSERT INTO admins (email, password_hash) VALUES ($1,$2) ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash', [email.toLowerCase(), hash]);
  console.log('Admin saved:', email);
  await pool.end();
})();
