const { randomBytes, scryptSync } = require("node:crypto");
const { database } = require("../lib/database");

const email = (process.env.NIZA_ADMIN_EMAIL || "").trim().toLowerCase();
const password = process.env.NIZA_ADMIN_PASSWORD || "";

if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
  console.error("Set NIZA_ADMIN_EMAIL to a valid email address.");
  process.exit(1);
}
if (password.length < 8) {
  console.error("Set NIZA_ADMIN_PASSWORD to at least 8 characters.");
  process.exit(1);
}

const salt = randomBytes(16);
const hash = scryptSync(password, salt, 64);
database.prepare(`
  INSERT INTO admins (email, password_salt, password_hash) VALUES (?, ?, ?)
  ON CONFLICT(email) DO UPDATE SET password_salt = excluded.password_salt, password_hash = excluded.password_hash
`).run(email, salt.toString("hex"), hash.toString("hex"));

console.log(`Admin account ready for ${email}.`);
database.close();
