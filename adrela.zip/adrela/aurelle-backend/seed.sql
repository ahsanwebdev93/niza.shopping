INSERT INTO products (name, category, price_pkr, stock, emoji) VALUES
('Court sneaker','Shoes',8500,25,'👟'),('Leather loafer','Shoes',12500,25,'👞'),
('Block heel sandal','Shoes',6900,25,'👡'),('Running trainer','Shoes',9800,25,'👟'),
('Everyday tote','Bags',14500,25,'👜'),('Crossbody bag','Bags',9900,25,'👛'),('City backpack','Bags',7800,25,'🎒'),
('Steel chronograph','Watches',18900,25,'⌚'),('Minimal leather watch','Watches',11500,25,'⌚'),('Rose gold ladies watch','Watches',13200,25,'⌚'),
('Matte lipstick','Makeup',1800,25,'💄'),('Silk foundation','Makeup',3200,25,'🧴'),('Eyeshadow palette','Makeup',2900,25,'🎨'),
('Cabin suitcase','Luggage',22500,25,'🧳'),('Large check-in case','Luggage',32000,25,'🧳'),('Travel duffel','Luggage',8900,25,'🧳'),
('Sunglasses','Other',4500,25,'🕶️'),('Leather wallet','Other',3900,25,'👝');
