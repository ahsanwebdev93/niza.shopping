const categories = ["All", "Shoes", "Bags", "Watches", "Makeup", "Luggage", "Other"];
const cardColors = ["#f6cbd8", "#d9d4f3", "#fbe3c8", "#cfe6f5"];
const cart = new Map();
let products = [];
let currentCategory = "All";

const byId = (id) => document.getElementById(id);
const formatPrice = (amount) => `Rs ${Number(amount).toLocaleString("en-PK")}`;

function escapeHtml(value) {
  const element = document.createElement("div");
  element.textContent = value;
  return element.innerHTML;
}

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`/api${path}`, {
      ...options,
      headers: options.body
        ? { "Content-Type": "application/json", ...options.headers }
        : options.headers
    });
  } catch {
    throw new Error("Store services are temporarily unavailable. Please try again later.");
  }

  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "The request could not be completed.");
  return result;
}

function renderCategories() {
  byId("tabs").innerHTML = categories.map((category) => `
    <button aria-pressed="${category === currentCategory}" data-category="${category}">
      ${category}
    </button>
  `).join("");
}

function renderProducts() {
  const visibleProducts = products.filter((product) =>
    currentCategory === "All" || product.category === currentCategory
  );

  byId("shop").innerHTML = visibleProducts.map((product) => `
    <article class="card">
      <div class="img" style="background:${cardColors[product.id % cardColors.length]}">${escapeHtml(product.emoji)}</div>
      <div class="body">
        <small>${escapeHtml(product.category)}</small>
        <h3>${escapeHtml(product.name)}</h3>
        <div class="row">
          <span class="price">${formatPrice(product.price_pkr)}</span>
          <button class="add" data-product="${product.id}" ${product.stock < 1 ? "disabled" : ""}>
            ${product.stock < 1 ? "Sold out" : "Add to cart"}
          </button>
        </div>
      </div>
    </article>
  `).join("");

  if (!visibleProducts.length) {
    byId("shop").innerHTML = '<p class="empty">No products in this category yet.</p>';
  }
}

function getCartTotal() {
  return [...cart].reduce((total, [id, quantity]) => {
    const product = products.find((item) => item.id === id);
    return total + (product ? product.price_pkr * quantity : 0);
  }, 0);
}

function renderCart() {
  const itemCount = [...cart.values()].reduce((sum, quantity) => sum + quantity, 0);
  byId("count").textContent = itemCount;
  byId("ctitle").textContent = "Your cart";

  if (itemCount === 0) {
    byId("items").innerHTML = '<div class="empty">Your cart is empty. Add something you like.</div>';
    byId("foot").innerHTML = "";
    return;
  }

  byId("items").innerHTML = [...cart].map(([id, quantity]) => {
    const product = products.find((item) => item.id === id);
    if (!product) return "";
    return `
      <div class="item">
        <div class="t" style="background:${cardColors[product.id % cardColors.length]}">${escapeHtml(product.emoji)}</div>
        <div>
          <strong>${escapeHtml(product.name)}</strong>
          <div class="qty">
            <button data-remove="${id}" aria-label="Remove one">−</button>
            ${quantity}
            <button data-add="${id}" aria-label="Add one">+</button>
          </div>
        </div>
        <div class="price">${formatPrice(product.price_pkr * quantity)}</div>
      </div>
    `;
  }).join("");

  byId("foot").innerHTML = `
    <div class="tot">
      <span>Total</span>
      <span>${formatPrice(getCartTotal())}</span>
    </div>
    <form id="checkout">
      <input name="name" placeholder="Full name" required autocomplete="name" maxlength="100">
      <input name="phone" type="tel" placeholder="Phone number" required autocomplete="tel">
      <input name="address" placeholder="Delivery address" required autocomplete="street-address" maxlength="300">
      <input name="city" placeholder="City" required autocomplete="address-level2" maxlength="60">
      <select name="payment">
        <option value="cod">Cash on delivery</option>
        <option value="bank_transfer">Bank transfer</option>
        <option value="wallet">JazzCash / Easypaisa</option>
      </select>
      <p class="checkout-error" id="checkout-error" role="alert" hidden></p>
      <button class="btn" type="submit">Place order</button>
    </form>
  `;
}

async function placeOrder(form) {
  const formData = new FormData(form);
  const button = form.querySelector('[type="submit"]');
  button.disabled = true;
  const errorMessage = byId("checkout-error");
  errorMessage.hidden = true;

  try {
    const order = await request("/orders", {
      method: "POST",
      body: JSON.stringify({
        customerName: formData.get("name"),
        phone: formData.get("phone"),
        address: formData.get("address"),
        city: formData.get("city"),
        paymentMethod: formData.get("payment"),
        items: [...cart].map(([productId, qty]) => ({ productId, qty }))
      })
    });
    const name = escapeHtml(formData.get("name"));
    const address = escapeHtml(formData.get("address"));
    const city = escapeHtml(formData.get("city"));
    const phone = escapeHtml(formData.get("phone"));
    const total = formatPrice(order.total_pkr);

    cart.clear();
    byId("count").textContent = "0";
    byId("items").innerHTML = `
      <div class="done">
        <h2>Order placed</h2>
        <p>
          Thank you, ${name}. Order ${escapeHtml(order.code)} for ${total} will be delivered to
          ${address}, ${city}. We will call ${phone} to confirm.
        </p>
        <button class="btn" id="continue-shopping">Keep shopping</button>
      </div>
    `;
    byId("foot").innerHTML = "";
    byId("continue-shopping").addEventListener("click", toggleCart);
    await loadProducts();
  } catch (error) {
    errorMessage.textContent = error.message;
    errorMessage.hidden = false;
    button.disabled = false;
  }
}

function toggleCart() {
  const isOpen = !byId("cart").classList.contains("on");
  byId("cart").classList.toggle("on", isOpen);
  byId("scrim").classList.toggle("on", isOpen);
  byId("cart").setAttribute("aria-hidden", String(!isOpen));
  if (isOpen) renderCart();
}

async function loadProducts() {
  try {
    const result = await request("/products");
    products = result;
    byId("catalog-message").hidden = true;
    renderProducts();
    renderCart();
  } catch (error) {
    byId("catalog-message").textContent = error.message;
    byId("catalog-message").hidden = false;
  }
}

byId("tabs").addEventListener("click", (event) => {
  const category = event.target.dataset.category;
  if (!category) return;
  currentCategory = category;
  renderCategories();
  renderProducts();
});

byId("shop").addEventListener("click", (event) => {
  const productId = Number(event.target.dataset.product);
  if (!productId) return;
  const product = products.find((item) => item.id === productId);
  if (!product || product.stock < (cart.get(productId) || 0) + 1) return;
  cart.set(productId, (cart.get(productId) || 0) + 1);
  renderCart();
});

byId("items").addEventListener("click", (event) => {
  const addId = Number(event.target.dataset.add);
  const removeId = Number(event.target.dataset.remove);
  if (addId) {
    const product = products.find((item) => item.id === addId);
    if (!product || product.stock <= cart.get(addId)) return;
    cart.set(addId, cart.get(addId) + 1);
  } else if (removeId) {
    const quantity = cart.get(removeId) - 1;
    if (quantity <= 0) cart.delete(removeId);
    else cart.set(removeId, quantity);
  } else {
    return;
  }
  renderCart();
});

byId("foot").addEventListener("submit", (event) => {
  if (event.target.id !== "checkout") return;
  event.preventDefault();
  placeOrder(event.target);
});

byId("open").addEventListener("click", toggleCart);
byId("close").addEventListener("click", toggleCart);
byId("scrim").addEventListener("click", toggleCart);
byId("shop-now").addEventListener("click", () => {
  byId("shop").scrollIntoView({ behavior: "smooth" });
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && byId("cart").classList.contains("on")) toggleCart();
});

renderCategories();
renderProducts();
renderCart();
loadProducts();
