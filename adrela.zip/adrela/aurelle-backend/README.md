# niza.shoppping backend (Node.js + Express + PostgreSQL)

## Run locally
1. Install Node 18+ and PostgreSQL, then create a database: `createdb aurelle`
2. `cp .env.example .env` and fill in DATABASE_URL and a long random JWT_SECRET
3. `npm install`
4. `npm run db:init`            (creates tables and loads the 18 sample products)
5. `npm run admin -- you@example.com YourStrongPassword`
6. `npm start`                   (API at http://localhost:3000)

For local development, keep `CORS_ORIGIN` set to `http://127.0.0.1:4173,http://localhost:4173`, then open the admin panel at [http://127.0.0.1:4173/admin](http://127.0.0.1:4173/admin). Sign in with the email and password created in step 5. The panel connects to the API and manages database products and orders.

## Deploy (Render / Railway)
Create a PostgreSQL database and a Node web service from this folder.
Set DATABASE_URL, DB_SSL=true, JWT_SECRET and CORS_ORIGIN (your store's domain).
Run `npm run db:init` and `npm run admin ...` once from the service shell.

## API
Public
- GET  /api/products?category=Shoes
- GET  /api/products/:id
- POST /api/orders   { customerName, phone, address, city, paymentMethod: "cod"|"bank_transfer"|"wallet", items: [{productId, qty}] }
- GET  /api/orders/:code?phone=03001234567        (order tracking)

Admin (header `Authorization: Bearer <token>`)
- POST   /api/admin/login   { email, password }  -> { token }
- GET    /api/admin/products
- POST   /api/admin/products
- PATCH  /api/admin/products/:id
- DELETE /api/admin/products/:id
- GET    /api/admin/orders?status=New
- PATCH  /api/admin/orders/:id/status   { status }
- GET    /api/admin/stats

## Notes
- Prices and totals are always computed on the server. Stock is locked and deducted inside one transaction.
- Cancelling an order returns its stock.
- Online payments (JazzCash, Easypaisa, cards) are not included: add a gateway in POST /api/orders when you have merchant credentials.
