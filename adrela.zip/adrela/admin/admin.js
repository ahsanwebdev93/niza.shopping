const TOKEN_KEY = "niza.admin.token";
const ORDER_STATUSES = ["New", "Confirmed", "Shipped", "Delivered", "Cancelled"];
const CATEGORIES = ["Shoes", "Bags", "Watches", "Makeup", "Luggage", "Other"];
const apiBase = `${window.location.origin}/api`;

const elements = {
  loginView: document.getElementById("login-view"),
  dashboardView: document.getElementById("dashboard-view"),
  loginForm: document.getElementById("login-form"),
  loginError: document.getElementById("login-error"),
  dashboardMessage: document.getElementById("dashboard-message"),
  pageTitle: document.getElementById("page-title"),
  productDialog: document.getElementById("product-dialog"),
  productForm: document.getElementById("product-form"),
  productFormError: document.getElementById("product-form-error")
};

let token = sessionStorage.getItem(TOKEN_KEY);
let activeView = "overview";
let products = [];

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function formatPrice(value) {
  return `Rs ${Number(value || 0).toLocaleString("en-PK")}`;
}

function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : date.toLocaleString();
}

function showMessage(element, message = "") {
  element.textContent = message;
  element.hidden = !message;
}

async function request(path, options = {}) {
  const headers = new Headers(options.headers);
  if (options.body) headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);

  let response;
  try {
    response = await fetch(`${apiBase}${path}`, { ...options, headers });
  } catch {
    throw new Error("Store services are temporarily unavailable. Please try again later.");
  }

  if (response.status === 401 && token) {
    signOut();
    showMessage(elements.loginError, "Your session expired. Please sign in again.");
    throw new Error("Your session expired. Please sign in again.");
  }

  if (response.status === 204) return null;

  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || `Request failed (${response.status}).`);
  return result;
}

function showDashboard() {
  elements.loginView.hidden = true;
  elements.dashboardView.hidden = false;
  showMessage(elements.loginError);
  loadView(activeView).catch((error) => showMessage(elements.dashboardMessage, error.message));
}

function signOut() {
  sessionStorage.removeItem(TOKEN_KEY);
  token = null;
  elements.dashboardView.hidden = true;
  elements.loginView.hidden = false;
  elements.loginForm.reset();
  elements.loginForm.elements.email.value = "ahsanbalouch5846@gmail.com";
}

async function loadStats() {
  const stats = await request("/admin/stats");
  document.getElementById("stat-products").textContent = stats.products;
  document.getElementById("stat-orders").textContent = stats.orders;
  document.getElementById("stat-new-orders").textContent = stats.new_orders;
  document.getElementById("stat-revenue").textContent = formatPrice(stats.revenue_pkr);
}

function orderRows(orders, showStatus = true) {
  if (!orders.length) return '<div class="empty-state">No orders found.</div>';

  const rows = orders.map((order) => {
    const items = (order.items || []).map((item) =>
      `${escapeHtml(item.name)} × ${escapeHtml(item.qty)}`
    ).join("<br>");
    const customer = `
      <span class="primary-cell">${escapeHtml(order.customer_name)}</span><br>
      ${escapeHtml(order.phone)}<br>
      ${escapeHtml(order.address)}, ${escapeHtml(order.city)}
    `;
    const status = showStatus
      ? `<select class="status-select" data-order-status="${Number(order.id)}" ${order.status === "Cancelled" ? "disabled" : ""}>
          ${ORDER_STATUSES.map((value) => `<option ${value === order.status ? "selected" : ""}>${value}</option>`).join("")}
        </select>`
      : `<span class="badge">${escapeHtml(order.status)}</span>`;

    return `<tr>
      <td><span class="primary-cell">${escapeHtml(order.code)}</span><br>${escapeHtml(formatDate(order.created_at))}</td>
      <td>${customer}</td>
      <td>${items || "—"}</td>
      <td>${formatPrice(order.total_pkr)}</td>
      <td>${status}</td>
    </tr>`;
  }).join("");

  return `<table class="data-table">
    <thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

async function loadOverview() {
  await loadStats();
  const orders = await request("/admin/orders");
  document.getElementById("recent-orders").innerHTML =
    orderRows(orders.slice(0, 5), false);
}

function productRows() {
  if (!products.length) return '<div class="empty-state">No products in your catalog.</div>';

  return `<table class="data-table">
    <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Availability</th><th>Actions</th></tr></thead>
    <tbody>${products.map((product) => `<tr>
      <td class="primary-cell">${escapeHtml(product.emoji)} ${escapeHtml(product.name)}</td>
      <td>${escapeHtml(product.category)}</td>
      <td>${formatPrice(product.price_pkr)}</td>
      <td>${Number(product.stock)}</td>
      <td><span class="badge ${product.active ? "" : "inactive"}">${product.active ? "Active" : "Hidden"}</span></td>
      <td><div class="row-actions">
        <button class="small-button" type="button" data-edit-product="${Number(product.id)}">Edit</button>
        <button class="small-button danger" type="button" data-delete-product="${Number(product.id)}">Delete</button>
      </div></td>
    </tr>`).join("")}</tbody>
  </table>`;
}

async function loadProducts() {
  products = await request("/admin/products");
  document.getElementById("products-table").innerHTML = productRows();
}

async function loadOrders() {
  const status = document.getElementById("order-filter").value;
  const query = status ? `?status=${encodeURIComponent(status)}` : "";
  const orders = await request(`/admin/orders${query}`);
  document.getElementById("orders-table").innerHTML = orderRows(orders);
}

async function loadView(view) {
  activeView = view;
  elements.pageTitle.textContent = view[0].toUpperCase() + view.slice(1);
  document.querySelectorAll(".content-view").forEach((section) => {
    section.hidden = section.id !== `${view}-view`;
  });
  document.querySelectorAll(".nav-link").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === view);
  });
  showMessage(elements.dashboardMessage);

  if (view === "overview") await loadOverview();
  if (view === "orders") await loadOrders();
  if (view === "products") await loadProducts();
}

function openProductDialog(product) {
  const form = elements.productForm;
  form.reset();
  form.elements.id.value = product?.id || "";
  form.elements.name.value = product?.name || "";
  form.elements.category.value = product?.category || CATEGORIES[0];
  form.elements.emoji.value = product?.emoji || "🛍️";
  form.elements.price.value = product?.price_pkr ?? "";
  form.elements.stock.value = product?.stock ?? "";
  form.elements.imageUrl.value = product?.image_url || "";
  form.elements.active.checked = product ? product.active : true;
  document.getElementById("product-dialog-title").textContent = product ? "Edit product" : "Add product";
  showMessage(elements.productFormError);
  elements.productDialog.showModal();
}

elements.loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  showMessage(elements.loginError);

  try {
    const formData = new FormData(elements.loginForm);
    const result = await request("/admin/login", {
      method: "POST",
      body: JSON.stringify({
        email: formData.get("email"),
        password: formData.get("password")
      })
    });
    token = result.token;
    sessionStorage.setItem(TOKEN_KEY, token);
    await loadView("overview");
    elements.loginView.hidden = true;
    elements.dashboardView.hidden = false;
  } catch (error) {
    showMessage(elements.loginError, error.message);
  }
});

document.querySelectorAll(".nav-link").forEach((button) => {
  button.addEventListener("click", () => {
    loadView(button.dataset.view).catch((error) => showMessage(elements.dashboardMessage, error.message));
  });
});

document.querySelectorAll("[data-open-view]").forEach((button) => {
  button.addEventListener("click", () => {
    loadView(button.dataset.openView).catch((error) => showMessage(elements.dashboardMessage, error.message));
  });
});

document.getElementById("logout-button").addEventListener("click", signOut);
document.getElementById("order-filter").addEventListener("change", () => {
  loadOrders().catch((error) => showMessage(elements.dashboardMessage, error.message));
});

document.getElementById("add-product-button").addEventListener("click", () => openProductDialog());
document.getElementById("close-product-dialog").addEventListener("click", () => elements.productDialog.close());

elements.productForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  showMessage(elements.productFormError);
  const formData = new FormData(elements.productForm);
  const id = formData.get("id");
  const product = {
    name: formData.get("name"),
    category: formData.get("category"),
    price_pkr: Number(formData.get("price")),
    stock: Number(formData.get("stock")),
    emoji: formData.get("emoji") || "🛍️",
    image_url: formData.get("imageUrl") || null,
    active: elements.productForm.elements.active.checked
  };

  try {
    await request(id ? `/admin/products/${id}` : "/admin/products", {
      method: id ? "PATCH" : "POST",
      body: JSON.stringify(product)
    });
    elements.productDialog.close();
    await loadProducts();
    await loadStats();
  } catch (error) {
    showMessage(elements.productFormError, error.message);
  }
});

document.getElementById("products-table").addEventListener("click", async (event) => {
  const editButton = event.target.closest("[data-edit-product]");
  const deleteButton = event.target.closest("[data-delete-product]");

  if (editButton) {
    const product = products.find((item) => item.id === Number(editButton.dataset.editProduct));
    if (product) openProductDialog(product);
    return;
  }

  if (deleteButton) {
    const id = Number(deleteButton.dataset.deleteProduct);
    const product = products.find((item) => item.id === id);
    if (!product || !confirm(`Delete "${product.name}"? This cannot be undone.`)) return;

    try {
      await request(`/admin/products/${id}`, { method: "DELETE" });
      await loadProducts();
      await loadStats();
    } catch (error) {
      showMessage(elements.dashboardMessage, error.message);
    }
  }
});

document.getElementById("orders-table").addEventListener("change", async (event) => {
  const select = event.target.closest("[data-order-status]");
  if (!select) return;

  try {
    await request(`/admin/orders/${select.dataset.orderStatus}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status: select.value })
    });
    await loadOrders();
    await loadStats();
  } catch (error) {
    showMessage(elements.dashboardMessage, error.message);
    await loadOrders();
  }
});

if (token) showDashboard();
